The crash is a created by a buffer overflow. 

To achieve the crash you must pass the if statement to create the buffer overflow. This can be done with 4 'a'.
Next, you must create the buffer overflow, which can be done by inputting 5 'a'.

The input that is in crash/crash1 should automatically crash by exploiting the uffer overflow.